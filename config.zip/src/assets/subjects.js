export const subjects = [
    {
        name: 'biology'
    },
    {
        name: 'english'
    },
    {
        name: 'math'
    },

]