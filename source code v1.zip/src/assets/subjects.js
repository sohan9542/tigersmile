export const subjects = [
    {
        name: 'Biology'
    },
    {
        name: 'English'
    },
    {
        name: 'Math'
    },
    {
        name: 'Computer Programming'
    },
    {
        name: 'Government'
    },
    {
        name: 'Economics'
    },
    {
        name: 'History'
    },
    {
        name: 'Theatre'
    },
    {
        name: 'Spanish'
    },
]